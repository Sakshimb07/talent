const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',           // your MySQL username
  password: 'Rahul@03',           // your MySQL password
  database: 'crm_db'      // your database name
});

db.connect((err) => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

module.exports = db;
