import React, { useState } from 'react';
import '../src/styles.css';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      alert('Email and password are required');
      return;
    }

    const loginInfo = { email, password };

    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginInfo),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Login failed');
      }

      alert(result.message);

      // Store token for authentication (Optional)
      if (result.token) {
        localStorage.setItem('token', result.token);
      }

      setTimeout(() => {
        navigate('/register'); // Redirect to the dashboard or home page
      }, 1000);
    } catch (error) {
      console.error('Login Error:', error);
      alert(`Error: ${error.message}`);
    }
  };

  return (
    <div className="container">
      <div className="login-box">
        <h2>CRM</h2>
        <p>Enter your credentials to access your account</p>
        <form onSubmit={handleLogin}>
          <label htmlFor="email">Email/Username</label>
          <input
            type="text"
            id="email"
            placeholder="Enter your email or username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <a href="#" className="forgot-password">Forgot Password?</a>

          <div className="remember-me">
            <input type="checkbox" id="remember" />
            <label htmlFor="remember">Remember for 30 days</label>
          </div>

          <button type="submit" className="login-btn">Login</button>

          <p className="register-link">Don't have an account? <a href="/register">Register here</a></p>
          <p className="admin-login">Are you an admin? <a href="/admin">Admin Login</a></p>
        </form>
        <p className="footer">Talent Corner HR Services Pvt. Ltd</p>
      </div>
    </div>
  );
};

export default Login;
