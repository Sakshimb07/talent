import React, { useState } from 'react';
import '../src/styles.css';
// import logoImage from '../assets/Logo.jpg';
import { useNavigate } from 'react-router-dom';


const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate =useNavigate();

  const handleAdminLogin = async (e) => {
    e.preventDefault();

    const loginInfo = { username, password };
    console.log(loginInfo);
    if (!loginInfo.username || !loginInfo.password) {
        alert("Username and password are required")
    }
    const url = 'http://localhost:5000/api/admin/login';
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginInfo),
      });
    
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Server returned invalid response');
      }
    
      const result = await response.json();
      if (result.success) {
        setTimeout(() => navigate('/register'), 1000);
        alert(result.message);
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert(error.message);
    }
    
  };

  return (
    <div className="container">
      <div className="login-box">
        <h2>CRM</h2>
        <h3>Admin Login</h3>
        <p>Enter your credentials to access the admin panel</p>
        <form onSubmit={handleAdminLogin}>
          <label htmlFor="username">Admin Username</label>
          <input
            type="text"
            id="username"
            placeholder="Enter your admin username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button type="submit" className="login-btn">Admin Login</button>

          <p className="register-link">Need an account? <a href="/register">Register here</a></p>
          <p className="admin-login">Go back to <a href="/">User Login</a></p>
        </form>
        <p className="footer">Talent Corner HR Services Pvt. Ltd</p>
      </div>

      {/* <div className="image-box">
        <img src={logoImage} alt="Logo" />
      </div> */}
    </div>
  );
};

export default AdminLogin;
